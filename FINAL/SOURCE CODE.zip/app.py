import streamlit as st
from PIL import Image
import numpy as np
import tensorflow as tf
import time

# --- 1. CONFIGURATION DAN LOAD MODEL ---
MODEL_PATH = "saved/best_finetuned.keras"
try:
    model = tf.keras.models.load_model(MODEL_PATH)
except Exception as e:
    st.error(f"Gagal memuat model dari {MODEL_PATH}. Error: {e}")
    st.stop()

# Label Kelas (dengan nama lebih profesional)
label_map = {
    0: {"name": "Hazardous", "description": "Bahan berbahaya dan beracun", "color": "#E53935"},
    1: {"name": "Non-Recyclable", "description": "Sampah tidak dapat didaur ulang", "color": "#757575"},
    2: {"name": "Organic", "description": "Sampah organik/biodegradable", "color": "#43A047"},
    3: {"name": "Recyclable", "description": "Bahan dapat didaur ulang", "color": "#1E88E5"}
}

IMG_SIZE = (224, 224)

# --- 2. CUSTOM CSS STYLING ---
st.markdown("""
<style>
    /* ===== VARIABLES & GLOBAL STYLES ===== */
    :root {
        --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        --secondary-gradient: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        --success-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        --warning-gradient: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
        --dark-gradient: linear-gradient(135deg, #2c3e50 0%, #4ca1af 100%);
        --glass-bg: rgba(255, 255, 255, 0.25);
        --glass-border: rgba(255, 255, 255, 0.18);
    }
    
    .main {
        padding: 2rem;
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        min-height: 100vh;
    }
    
    /* ===== HEADER ENHANCED ===== */
    .header-container {
        background: var(--dark-gradient);
        padding: 3rem 2rem;
        border-radius: 20px;
        margin-bottom: 2rem;
        color: white;
        text-align: center;
        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        position: relative;
        overflow: hidden;
        animation: fadeInDown 0.8s ease;
    }
    
    .header-container::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z' fill='%23ffffff' fill-opacity='0.1' fill-rule='evenodd'/%3E%3C/svg%3E");
        opacity: 0.3;
    }
    
    .header-title {
        font-size: 3rem;
        font-weight: 800;
        margin-bottom: 0.5rem;
        background: linear-gradient(to right, #ffffff, #ffeaa7);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        animation: glow 2s ease-in-out infinite alternate;
    }
    
    .header-subtitle {
        font-size: 1.2rem;
        opacity: 0.95;
        max-width: 700px;
        margin: 0 auto;
        line-height: 1.6;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
    }
    
    /* ===== GLASSMORPHISM CARDS ===== */
    .card {
        background: var(--glass-bg);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        border-radius: 20px;
        padding: 2rem;
        box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        border: 1px solid var(--glass-border);
        margin-bottom: 2rem;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        animation: slideInUp 0.6s ease;
    }
    
    .card:hover {
        transform: translateY(-10px) scale(1.02);
        box-shadow: 0 15px 35px rgba(0,0,0,0.15);
    }
    
    .prediction-card {
        border-left: 6px solid;
        position: relative;
        overflow: hidden;
        animation: pulse 2s infinite;
    }
    
    .prediction-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(45deg, transparent 30%, rgba(255,255,255,0.1) 50%, transparent 70%);
        animation: shimmer 3s infinite;
    }
    
    /* ===== UPLOAD AREA ENHANCED ===== */
    .upload-area {
        border: 3px dashed;
        border-image: var(--primary-gradient) 1;
        border-radius: 20px;
        padding: 4rem 2rem;
        text-align: center;
        background: rgba(255, 255, 255, 0.1);
        margin: 1.5rem 0;
        transition: all 0.3s ease;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
    
    .upload-area:hover {
        background: rgba(255, 255, 255, 0.2);
        transform: scale(1.02);
        box-shadow: 0 10px 25px rgba(102, 126, 234, 0.2);
    }
    
    .upload-area::after {
        content: '📁';
        font-size: 4rem;
        position: absolute;
        bottom: -20px;
        right: -20px;
        opacity: 0.1;
        transform: rotate(-15deg);
    }
    
    /* ===== BUTTONS WITH NEON EFFECT ===== */
    .stButton > button {
        background: var(--primary-gradient);
        color: white;
        border: none;
        padding: 1rem 2rem;
        border-radius: 15px;
        font-weight: 700;
        font-size: 1.1rem;
        transition: all 0.4s ease;
        width: 100%;
        position: relative;
        overflow: hidden;
        text-transform: uppercase;
        letter-spacing: 1px;
        box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
    }
    
    .stButton > button::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
        transition: 0.5s;
    }
    
    .stButton > button:hover {
        transform: translateY(-3px) scale(1.05);
        box-shadow: 0 10px 25px rgba(102, 126, 234, 0.6);
    }
    
    .stButton > button:hover::before {
        left: 100%;
    }
    
    /* ===== CONFIDENCE METER ANIMATED ===== */
    .confidence-meter {
        background: linear-gradient(90deg, #e0e0e0, #f5f5f5);
        border-radius: 25px;
        height: 20px;
        margin: 2rem 0;
        overflow: hidden;
        position: relative;
        box-shadow: inset 0 2px 10px rgba(0,0,0,0.1);
    }
    
    .confidence-fill {
        height: 100%;
        border-radius: 25px;
        transition: width 1.5s cubic-bezier(0.34, 1.56, 0.64, 1);
        position: relative;
        background: var(--primary-gradient);
        box-shadow: 0 0 20px rgba(102, 126, 234, 0.5);
    }
    
    .confidence-fill::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(90deg, 
            transparent 0%, 
            rgba(255,255,255,0.3) 50%, 
            transparent 100%);
        animation: shine 2s infinite;
    }
    
    /* ===== SIDEBAR ENHANCED ===== */
    .sidebar .sidebar-content {
        background: var(--dark-gradient);
        box-shadow: 5px 0 25px rgba(0,0,0,0.2);
    }
    
    .sidebar-title {
        color: white;
        font-size: 1.8rem;
        margin-bottom: 1rem;
        text-align: center;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        background: linear-gradient(to right, #ffecd2, #fcb69f);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    
    /* ===== STATS CARDS ENHANCED ===== */
    .stat-card {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(5px);
        padding: 1.5rem;
        border-radius: 15px;
        text-align: center;
        margin-bottom: 1rem;
        transition: all 0.3s ease;
        border: 1px solid rgba(255,255,255,0.1);
        animation: float 6s ease-in-out infinite;
    }
    
    .stat-card:hover {
        transform: scale(1.05);
        background: rgba(255, 255, 255, 0.2);
    }
    
    .stat-value {
        font-size: 2.5rem;
        font-weight: 900;
        color: #ffffff;
        text-shadow: 0 2px 10px rgba(0,0,0,0.3);
    }
    
    .stat-label {
        font-size: 0.9rem;
        color: rgba(255,255,255,0.8);
        text-transform: uppercase;
        letter-spacing: 2px;
        font-weight: 600;
    }
    
    /* ===== CATEGORY CHIPS ===== */
    .category-chip {
        display: inline-flex;
        align-items: center;
        padding: 0.5rem 1rem;
        margin: 0.25rem;
        border-radius: 50px;
        font-weight: 600;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        transition: all 0.3s ease;
        animation: bounceIn 0.6s ease;
    }
    
    .category-chip:hover {
        transform: scale(1.1) rotate(5deg);
        box-shadow: 0 6px 20px rgba(0,0,0,0.2);
    }
    
    /* ===== ANIMATIONS ===== */
    @keyframes fadeInDown {
        from {
            opacity: 0;
            transform: translateY(-30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    @keyframes slideInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    @keyframes glow {
        from {
            text-shadow: 0 0 10px #fff, 0 0 20px #fff, 0 0 30px #667eea;
        }
        to {
            text-shadow: 0 0 20px #fff, 0 0 30px #764ba2, 0 0 40px #764ba2;
        }
    }
    
    @keyframes pulse {
        0% {
            box-shadow: 0 0 0 0 rgba(102, 126, 234, 0.4);
        }
        70% {
            box-shadow: 0 0 0 10px rgba(102, 126, 234, 0);
        }
        100% {
            box-shadow: 0 0 0 0 rgba(102, 126, 234, 0);
        }
    }
    
    @keyframes float {
        0% {
            transform: translateY(0px);
        }
        50% {
            transform: translateY(-10px);
        }
        100% {
            transform: translateY(0px);
        }
    }
    
    @keyframes shimmer {
        0% {
            transform: translateX(-100%);
        }
        100% {
            transform: translateX(100%);
        }
    }
    
    @keyframes shine {
        0% {
            opacity: 0;
            transform: translateX(-100%);
        }
        50% {
            opacity: 1;
        }
        100% {
            opacity: 0;
            transform: translateX(100%);
        }
    }
    
    @keyframes bounceIn {
        0% {
            transform: scale(0.3);
            opacity: 0;
        }
        50% {
            transform: scale(1.05);
        }
        70% {
            transform: scale(0.9);
        }
        100% {
            transform: scale(1);
            opacity: 1;
        }
    }
    
    /* ===== LOADING SPINNER ===== */
    .spinner {
        width: 50px;
        height: 50px;
        border: 5px solid #f3f3f3;
        border-top: 5px solid #667eea;
        border-radius: 50%;
        animation: spin 1s linear infinite;
        margin: 2rem auto;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    /* ===== RESPONSIVE DESIGN ===== */
    @media (max-width: 768px) {
        .header-title {
            font-size: 2rem;
        }
        
        .card {
            padding: 1rem;
        }
        
        .upload-area {
            padding: 2rem 1rem;
        }
    }
</style>
""", unsafe_allow_html=True)

# --- 3. PAGE SETTINGS ---
st.set_page_config(
    page_title="Smart Waste Classifier",
    layout="wide",
    initial_sidebar_state="expanded",
    page_icon="🗑️"
)

# --- 4. SIDEBAR ---
with st.sidebar:
    st.markdown("""
        <div style='padding: 1rem;'>
            <h2 style='color: white;'>Model Analytics</h2>
        </div>
    """, unsafe_allow_html=True)
    
    # Model Stats
    st.markdown("""
        <div class='stat-card'>
            <div class='stat-value'>76%</div>
            <div class='stat-label'>Accuracy</div>
        </div>
    """, unsafe_allow_html=True)
    
    st.divider()
    
    # Model Details
    st.markdown("### Model Specifications")
    st.markdown("""
    - **Architecture**: MobileNetV2 Fine-tuned
    - **Input Size**: 224×224 pixels
    - **Classes**: 4 Categories
    - **Training Dataset**: Custom Waste Collection
    """)
    
    st.divider()
    
    # Category Guide
    st.markdown("### Waste Categories")
    for i, (key, value) in enumerate(label_map.items()):
        st.markdown(f"""
            <div style='display: flex; align-items: center; margin-bottom: 0.5rem;'>
                <div style='width: 12px; height: 12px; background-color: {value["color"]}; 
                     border-radius: 50%; margin-right: 10px;'></div>
                <span style='color: white;'>{value["name"]}</span>
            </div>
        """, unsafe_allow_html=True)
    
    st.divider()
    
    # Improvement Roadmap
    st.markdown("### Improvement Roadmap")
    st.info("""
    - Enhanced dataset collection
    - Data augmentation techniques
    - Real-time performance metrics
    - Multi-model ensemble approach
    """)

# --- 5. MAIN CONTENT ---
# Header Section
st.markdown("""
    <div class='header-container'>
        <h1 class='header-title'>Smart Waste Classifier</h1>
        <p class='header-subtitle'>
            Advanced AI-powered waste classification system using deep learning
            for efficient waste management and recycling optimization
        </p>
    </div>
""", unsafe_allow_html=True)

# Main Content Layout
col1, col2 = st.columns([1, 1])

with col1:
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.markdown("### Image Input")
    st.markdown("Upload an image of waste material for classification analysis")
    
    # Upload Section
    uploaded_file = st.file_uploader(
        "Choose an image file",
        type=["jpg", "png", "jpeg"],
        help="Supported formats: JPG, PNG, JPEG",
        label_visibility="collapsed"
    )
    
    if uploaded_file:
        img = Image.open(uploaded_file)
        st.image(img, use_column_width=True, caption="Uploaded Image")
        
        # Predict Button
        if st.button("Analyze Waste Category", type="primary"):
            with st.spinner('Processing image with AI model...'):
                time.sleep(1)
                
                # Preprocess
                img_resized = img.resize(IMG_SIZE)
                img_array = np.array(img_resized) / 255.0
                img_array = np.expand_dims(img_array, axis=0)
                
                # Predict
                pred = model.predict(img_array)[0]
                class_id = np.argmax(pred)
                confidence = float(pred[class_id] * 100)
                
                # Get class details
                class_detail = label_map[class_id]
                class_name = class_detail["name"]
                class_color = class_detail["color"]
                class_desc = class_detail["description"]
                
                # Store results in session state
                st.session_state.prediction_result = {
                    'class_id': class_id,
                    'class_name': class_name,
                    'class_color': class_color,
                    'confidence': confidence,
                    'description': class_desc
                }
                
                st.rerun()
    else:
        st.markdown("""
            <div class='upload-area'>
                <div style='font-size: 4rem; margin-bottom: 1rem;'>📷</div>
                <h3>Drag & Drop or Click to Upload</h3>
                <p style='color: #666;'>Upload an image of waste material for analysis</p>
            </div>
        """, unsafe_allow_html=True)
    
    st.markdown("</div>", unsafe_allow_html=True)

with col2:
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.markdown("### Analysis Results")
    
    if 'prediction_result' in st.session_state:
        result = st.session_state.prediction_result
        
        st.markdown(f"""
            <div class='prediction-card' style='border-left-color: {result["class_color"]};'>
                <h2 style='color: {result["class_color"]}; margin-bottom: 0.5rem;'>
                    {result["class_name"]}
                </h2>
                <p style='color: #666; margin-bottom: 1.5rem;'>{result["description"]}</p>
            </div>
        """, unsafe_allow_html=True)
        
        # Confidence Visualization
        st.markdown("#### Confidence Level")
        confidence = result["confidence"]
        
        # Custom confidence meter
        st.markdown(f"""
            <div class='confidence-meter'>
                <div class='confidence-fill' style='width: {confidence}%; background: {result["class_color"]};'></div>
            </div>
            <div style='display: flex; justify-content: space-between; margin-top: 0.5rem;'>
                <span style='color: #666;'>0%</span>
                <span style='font-weight: 600; color: {result["class_color"]};'>{confidence:.1f}%</span>
                <span style='color: #666;'>100%</span>
            </div>
        """, unsafe_allow_html=True)
        
        # Status Indicator
        if confidence >= 80:
            status = "High Confidence"
            status_color = "#4CAF50"
        elif confidence >= 60:
            status = "Medium Confidence"
            status_color = "#FF9800"
        else:
            status = "Low Confidence"
            status_color = "#F44336"
        
        st.markdown(f"""
            <div style='display: flex; align-items: center; margin: 1.5rem 0;'>
                <div style='width: 10px; height: 10px; background-color: {status_color}; 
                     border-radius: 50%; margin-right: 10px;'></div>
                <span>Classification Status: <strong>{status}</strong></span>
            </div>
        """, unsafe_allow_html=True)
        
        # Recommendations
        st.markdown("#### Recommended Action")
        recommendations = {
            "Hazardous": "Handle with protective equipment. Dispose at designated hazardous waste facility.",
            "Non-Recyclable": "Dispose in general waste. Consider waste-to-energy options if available.",
            "Organic": "Compost or use for biogas production. Avoid landfill disposal.",
            "Recyclable": "Clean and separate material. Send to appropriate recycling facility."
        }
        
        st.info(recommendations.get(result["class_name"], "Consult local waste management guidelines."))
        
        # Reset Button
        if st.button("Analyze Another Image"):
            del st.session_state.prediction_result
            st.rerun()
    else:
        st.markdown("""
            <div style='text-align: center; padding: 3rem; color: #999;'>
                <div style='font-size: 3rem; margin-bottom: 1rem;'>🔍</div>
                <h3>Awaiting Analysis</h3>
                <p>Upload an image and click "Analyze Waste Category" to see results</p>
            </div>
        """, unsafe_allow_html=True)
    
    st.markdown("</div>", unsafe_allow_html=True)

# Footer Section
st.markdown("---")
st.markdown("""
    <div style='text-align: center; color: #666; padding: 1rem;'>
        <p>Smart Waste Classifier v1.0 | Deep Learning Model | For Environmental Sustainability</p>
        <p style='font-size: 0.9rem;'>This system assists in waste classification and should be used as guidance only.</p>
    </div>
""", unsafe_allow_html=True)